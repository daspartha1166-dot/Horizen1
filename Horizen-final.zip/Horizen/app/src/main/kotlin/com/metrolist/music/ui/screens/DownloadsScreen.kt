/**
 * Horizen — Downloads manager.
 *
 * One place to see everything that is downloading, queued, paused, failed or finished,
 * with bulk actions (pause / resume / retry failed / cancel all) and per-song controls.
 */

package com.metrolist.music.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadService
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import com.metrolist.music.LocalDatabase
import com.metrolist.music.LocalDownloadUtil
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.playback.ExoDownloadService
import com.metrolist.music.ui.component.downloadProgress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private fun Download.isActive() =
    state == Download.STATE_QUEUED || state == Download.STATE_DOWNLOADING || state == Download.STATE_RESTARTING

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(navController: NavController) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val downloadUtil = LocalDownloadUtil.current
    val scope = rememberCoroutineScope()
    val downloads by downloadUtil.downloads.collectAsStateWithLifecycle()

    val all = remember(downloads) { downloads.values.sortedByDescending { it.updateTimeMs } }
    val unfinished = remember(all) { all.filter { it.state != Download.STATE_COMPLETED } }
    val completed = remember(all) { all.filter { it.state == Download.STATE_COMPLETED } }
    val runningCount = remember(unfinished) { unfinished.count { it.isActive() } }
    val failed = remember(unfinished) { unfinished.filter { it.state == Download.STATE_FAILED } }
    val overallProgress =
        remember(unfinished) {
            val values = unfinished.filter { it.isActive() }.mapNotNull { downloadProgress(it) }
            if (values.isEmpty()) null else values.average().toFloat()
        }

    val pauseAll = { DownloadService.sendPauseDownloads(context, ExoDownloadService::class.java, false) }
    val resumeAll = { DownloadService.sendResumeDownloads(context, ExoDownloadService::class.java, false) }
    val cancelAll = {
        unfinished.forEach { download ->
            DownloadService.sendRemoveDownload(context, ExoDownloadService::class.java, download.request.id, false)
        }
    }
    val retryFailed = {
        scope.launch(Dispatchers.IO) {
            failed.forEach { download ->
                database.getSongById(download.request.id)?.let { downloadUtil.download(it) }
            }
        }
        Unit
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding =
                LocalPlayerAwareWindowInsets.current
                    .only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom)
                    .asPaddingValues(),
            modifier =
                Modifier.windowInsetsPadding(
                    LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Top),
                ),
        ) {
            item(key = "summary") {
                SummaryCard(
                    running = runningCount,
                    waiting = unfinished.size - runningCount,
                    done = completed.size,
                    progress = overallProgress,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }

            item(key = "actions") {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 8.dp),
                ) {
                    item {
                        ActionChip(R.drawable.pause, stringResource(R.string.dl_pause_all), onClick = pauseAll)
                    }
                    item {
                        ActionChip(R.drawable.play, stringResource(R.string.dl_resume_all), onClick = resumeAll)
                    }
                    if (failed.isNotEmpty()) {
                        item {
                            ActionChip(R.drawable.refresh, stringResource(R.string.dl_retry_failed), onClick = retryFailed)
                        }
                    }
                    if (unfinished.isNotEmpty()) {
                        item {
                            ActionChip(R.drawable.close, stringResource(R.string.dl_cancel_all), onClick = cancelAll)
                        }
                    }
                }
            }

            if (all.isEmpty()) {
                item(key = "empty") {
                    Text(
                        text = stringResource(R.string.dl_empty),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                    )
                }
            }

            if (unfinished.isNotEmpty()) {
                item(key = "header_active") {
                    SectionHeader(stringResource(R.string.dl_in_progress, unfinished.size))
                }
                items(unfinished, key = { "dl_active_${it.request.id}" }) { download ->
                    DownloadRow(download, modifier = Modifier.animateItem())
                }
            }

            if (completed.isNotEmpty()) {
                item(key = "header_done") {
                    SectionHeader(stringResource(R.string.dl_completed, completed.size))
                }
                items(completed, key = { "dl_done_${it.request.id}" }) { download ->
                    DownloadRow(download, modifier = Modifier.animateItem())
                }
            }
        }

        TopAppBar(
            title = { Text(stringResource(R.string.dl_title)) },
            navigationIcon = {
                IconButton(onClick = { navController.navigateUp() }) {
                    Icon(
                        painter = painterResource(R.drawable.arrow_back),
                        contentDescription = null,
                    )
                }
            },
            modifier = Modifier.align(Alignment.TopStart),
        )
    }
}

@Composable
private fun SummaryCard(
    running: Int,
    waiting: Int,
    done: Int,
    progress: Float?,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = running.toString(),
                    style = MaterialTheme.typography.displaySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.dl_summary_downloading),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.dl_summary_detail, waiting, done),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (running > 0) {
                Spacer(Modifier.height(14.dp))
                if (progress == null) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun ActionChip(
    iconRes: Int,
    label: String,
    onClick: () -> Unit,
) {
    AssistChip(
        onClick = onClick,
        label = { Text(label) },
        leadingIcon = {
            Icon(
                painter = painterResource(iconRes),
                contentDescription = null,
                modifier = Modifier.size(18.dp),
            )
        },
    )
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 6.dp),
    )
}

@Composable
private fun DownloadRow(
    download: Download,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val downloadUtil = LocalDownloadUtil.current
    val scope = rememberCoroutineScope()
    val songId = download.request.id
    val song by database.song(songId).collectAsStateWithLifecycle(initialValue = null)

    val progress = downloadProgress(download)
    val percentText = progress?.let { " · ${(it * 100).toInt()}%" }.orEmpty()
    val status =
        when (download.state) {
            Download.STATE_QUEUED -> stringResource(R.string.dl_status_queued)
            Download.STATE_DOWNLOADING, Download.STATE_RESTARTING -> stringResource(R.string.downloading) + percentText
            Download.STATE_STOPPED -> stringResource(R.string.dl_status_paused)
            Download.STATE_FAILED -> stringResource(R.string.dl_status_failed)
            Download.STATE_COMPLETED -> stringResource(R.string.dl_status_done)
            else -> ""
        }
    val statusColor =
        if (download.state == Download.STATE_FAILED) MaterialTheme.colorScheme.error
        else MaterialTheme.colorScheme.onSurfaceVariant

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
    ) {
        Box(
            modifier =
                Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
        ) {
            AsyncImage(
                model = song?.song?.thumbnailUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }

        Column(
            modifier =
                Modifier
                    .weight(1f)
                    .padding(horizontal = 14.dp),
        ) {
            Text(
                text = song?.song?.title ?: songId,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = status,
                style = MaterialTheme.typography.bodySmall,
                color = statusColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (download.isActive()) {
                Spacer(Modifier.height(6.dp))
                if (progress == null) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                }
            }
        }

        when (download.state) {
            Download.STATE_FAILED ->
                IconButton(
                    onClick = {
                        scope.launch(Dispatchers.IO) {
                            database.getSongById(songId)?.let { downloadUtil.download(it) }
                        }
                    },
                ) {
                    Icon(painter = painterResource(R.drawable.refresh), contentDescription = null)
                }

            Download.STATE_COMPLETED ->
                IconButton(
                    onClick = {
                        DownloadService.sendRemoveDownload(context, ExoDownloadService::class.java, songId, false)
                    },
                ) {
                    Icon(painter = painterResource(R.drawable.delete), contentDescription = null)
                }

            else ->
                IconButton(
                    onClick = {
                        DownloadService.sendRemoveDownload(context, ExoDownloadService::class.java, songId, false)
                    },
                ) {
                    Icon(painter = painterResource(R.drawable.close), contentDescription = null)
                }
        }
    }
}
