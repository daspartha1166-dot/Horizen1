/**
 * Horizen — on-device recommendation engine.
 *
 * Everything is computed locally from the listening history already stored in the database;
 * no listening data ever leaves the phone.
 *
 * Pipeline
 *  1. Per-play signal: how much of the song was actually heard (skips count against it).
 *  2. Recency decay: every play is weighted by an exponential half-life, so taste can drift.
 *  3. Song score = decayed play signal + bonuses for likes / downloads.
 *  4. Artist affinity + "co-listening" graph (which artists share listening sessions).
 *  5. Mixes: Made for You, Daily Mix (artist clusters), Right Now (time-of-day),
 *     Rediscover (loved but not heard lately), Discover (related songs you never played).
 *  6. Smart ordering: artists are spread out so the same artist never plays back-to-back.
 */

package com.metrolist.music.recommendation

import com.metrolist.music.db.MusicDatabase
import com.metrolist.music.db.entities.Event
import com.metrolist.music.db.entities.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.LocalDateTime
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.pow
import kotlin.random.Random

/** Tunable constants, kept together so the engine's "taste" is easy to adjust. */
internal object RecommendationConfig {
    const val HISTORY_DAYS = 150L
    const val MAX_EVENTS = 30_000
    const val HALF_LIFE_DAYS = 21.0
    const val SKIP_COMPLETION = 0.2
    const val SKIP_PENALTY = -0.6
    const val LIKE_BONUS = 2.0
    const val DOWNLOAD_BONUS = 0.5
    const val SESSION_GAP_MINUTES = 45L
    const val MAX_SESSION_ARTISTS = 12
    const val RECENTLY_PLAYED_HOURS = 3L
    const val REDISCOVER_AFTER_DAYS = 30L
    const val MIN_PLAYS_FOR_REDISCOVER = 3
    const val MAX_PER_ARTIST = 3
    const val MADE_FOR_YOU_SIZE = 30
    const val DAILY_MIX_COUNT = 4
    const val DAILY_MIX_SIZE = 24
    const val SHELF_SIZE = 25
    const val MIN_MIX_SIZE = 6
    const val DB_CHUNK = 400
}

@Singleton
class RecommendationEngine
@Inject
constructor(
    private val database: MusicDatabase,
) {
    /**
     * Builds every mix for the home screen. Safe to call from any dispatcher; the heavy work runs on IO.
     * Returns an empty list while there is not enough history to say anything useful.
     */
    suspend fun buildShelves(
        hideVideoSongs: Boolean,
        now: LocalDateTime = LocalDateTime.now(),
    ): List<RecommendationMix> =
        withContext(Dispatchers.IO) {
            val events =
                database.recentEvents(
                    fromTimeStamp = now.minusDays(RecommendationConfig.HISTORY_DAYS),
                    limit = RecommendationConfig.MAX_EVENTS,
                )
            val liked = database.likedSongsByCreateDateAsc().first()
            val profile = buildProfile(events, liked, now)
            if (profile.songScore.isEmpty()) return@withContext emptyList()

            val dayRandom = Random(now.toLocalDate().toEpochDay())
            val allowed: (Song) -> Boolean = { !hideVideoSongs || !it.song.isVideo }

            buildList {
                madeForYou(profile, now, dayRandom, allowed)?.let { add(it) }
                addAll(dailyMixes(profile, now, allowed))
                timeOfDay(profile, now, allowed)?.let { add(it) }
                rediscover(profile, now, allowed)?.let { add(it) }
                discover(profile, dayRandom, allowed)?.let { add(it) }
            }
        }

    // ---------------------------------------------------------------------------------------------
    // Profile
    // ---------------------------------------------------------------------------------------------

    private suspend fun buildProfile(
        events: List<Event>,
        liked: List<Song>,
        now: LocalDateTime,
    ): TasteProfile {
        val songs = HashMap<String, Song>()
        liked.forEach { songs[it.id] = it }
        events
            .map { it.songId }
            .distinct()
            .filter { it !in songs }
            .chunked(RecommendationConfig.DB_CHUNK)
            .forEach { chunk -> database.getSongsByIds(chunk).forEach { songs[it.id] = it } }

        val score = HashMap<String, Double>()
        val playCount = HashMap<String, Int>()
        val lastPlayed = HashMap<String, LocalDateTime>()
        val bucketScore = TimeBucket.values().associateWith { HashMap<String, Double>() }

        for (event in events) {
            val song = songs[event.songId] ?: continue
            if (song.song.isEpisode) continue

            val ageDays = Duration.between(event.timestamp, now).toMinutes() / 1440.0
            val recency = 0.5.pow(ageDays.coerceAtLeast(0.0) / RecommendationConfig.HALF_LIFE_DAYS)

            val durationMs = song.song.duration * 1000L
            val completion =
                if (durationMs > 0) (event.playTime.toDouble() / durationMs).coerceIn(0.0, 1.5) else 0.6
            val signal =
                if (completion < RecommendationConfig.SKIP_COMPLETION) {
                    RecommendationConfig.SKIP_PENALTY
                } else {
                    0.4 + 0.6 * completion.coerceAtMost(1.0)
                }

            score[event.songId] = (score[event.songId] ?: 0.0) + recency * signal
            playCount[event.songId] = (playCount[event.songId] ?: 0) + 1
            val previous = lastPlayed[event.songId]
            if (previous == null || event.timestamp.isAfter(previous)) lastPlayed[event.songId] = event.timestamp
            if (signal > 0) {
                val bucket = bucketScore.getValue(TimeBucket.of(event.timestamp.hour))
                bucket[event.songId] = (bucket[event.songId] ?: 0.0) + recency * signal
            }
        }

        for ((id, song) in songs) {
            var s = score[id] ?: 0.0
            if (song.song.liked) s += RecommendationConfig.LIKE_BONUS
            if (song.song.isDownloaded) s += RecommendationConfig.DOWNLOAD_BONUS
            score[id] = s
        }
        val positive = score.filterValues { it > 0.0 }

        // Artist affinity.
        val artistScore = HashMap<String, Double>()
        val artistNames = HashMap<String, String>()
        val artistSongs = HashMap<String, MutableList<String>>()
        for ((id, s) in positive) {
            val song = songs[id] ?: continue
            for (artist in song.artists) {
                artistScore[artist.id] = (artistScore[artist.id] ?: 0.0) + s
                artistNames[artist.id] = artist.name
                artistSongs.getOrPut(artist.id) { mutableListOf() }.add(id)
            }
        }

        return TasteProfile(
            songs = songs,
            songScore = positive,
            playCount = playCount,
            lastPlayed = lastPlayed,
            playedIds = playCount.keys.toSet(),
            artistScore = artistScore,
            artistNames = artistNames,
            artistSongs = artistSongs,
            coListen = buildCoListening(events, songs),
            bucketScore = bucketScore,
        )
    }

    /** Counts how often two artists show up in the same listening session (events < 45 min apart). */
    private fun buildCoListening(
        events: List<Event>,
        songs: Map<String, Song>,
    ): Map<String, Map<String, Int>> {
        val result = HashMap<String, HashMap<String, Int>>()
        val session = LinkedHashSet<String>()
        var lastTime: LocalDateTime? = null

        fun flush() {
            val artists = session.take(RecommendationConfig.MAX_SESSION_ARTISTS)
            for (a in artists) {
                for (b in artists) {
                    if (a == b) continue
                    val row = result.getOrPut(a) { HashMap() }
                    row[b] = (row[b] ?: 0) + 1
                }
            }
            session.clear()
        }

        for (event in events.sortedBy { it.timestamp }) {
            val artistId = songs[event.songId]?.artists?.firstOrNull()?.id ?: continue
            val previous = lastTime
            if (previous != null &&
                Duration.between(previous, event.timestamp).toMinutes() > RecommendationConfig.SESSION_GAP_MINUTES
            ) {
                flush()
            }
            session.add(artistId)
            lastTime = event.timestamp
        }
        flush()
        return result
    }

    // ---------------------------------------------------------------------------------------------
    // Mixes
    // ---------------------------------------------------------------------------------------------

    private fun rankedIds(profile: TasteProfile): List<String> =
        profile.songScore.entries.sortedByDescending { it.value }.map { it.key }

    /** Your overall best bets, with a pinch of exploration so it never goes stale. */
    private fun madeForYou(
        profile: TasteProfile,
        now: LocalDateTime,
        random: Random,
        allowed: (Song) -> Boolean,
    ): RecommendationMix? {
        val cutoff = now.minusHours(RecommendationConfig.RECENTLY_PLAYED_HOURS)
        val favourites =
            rankedIds(profile)
                .filter { id -> profile.lastPlayed[id]?.isBefore(cutoff) != false }
                .mapNotNull { profile.songs[it] }
                .filter(allowed)

        val diversified = diversify(favourites, RecommendationConfig.MADE_FOR_YOU_SIZE)
        if (diversified.size < RecommendationConfig.MIN_MIX_SIZE) return null

        val explore =
            relatedUnplayed(profile, rankedIds(profile).take(5), allowed)
                .shuffled(random)
                .take(RecommendationConfig.MADE_FOR_YOU_SIZE / 4)

        // Sprinkle one exploratory song after every three familiar ones.
        val mixed = ArrayList<Song>(diversified.size + explore.size)
        val exploreQueue = ArrayDeque(explore)
        diversified.forEachIndexed { index, song ->
            mixed += song
            if ((index + 1) % 3 == 0) exploreQueue.removeFirstOrNull()?.let { mixed += it }
        }
        mixed.addAll(exploreQueue)

        return RecommendationMix(
            id = "made_for_you",
            kind = MixKind.MADE_FOR_YOU,
            title = "Made for You",
            subtitle = artistLine(profile, topArtists(profile, 3)),
            songs = spaceArtists(mixed.distinctBy { it.id }),
        )
    }

    /** Artist clusters: a top artist plus the artists you tend to play in the same sessions. */
    private fun dailyMixes(
        profile: TasteProfile,
        now: LocalDateTime,
        allowed: (Song) -> Boolean,
    ): List<RecommendationMix> {
        val unassigned =
            profile.artistScore.entries
                .sortedByDescending { it.value }
                .map { it.key }
                .filter { (profile.artistSongs[it]?.size ?: 0) >= 2 }
                .toMutableList()

        val mixes = mutableListOf<RecommendationMix>()
        var number = 1
        while (unassigned.isNotEmpty() && mixes.size < RecommendationConfig.DAILY_MIX_COUNT) {
            val seed = unassigned.removeAt(0)
            val friends =
                profile.coListen[seed].orEmpty().entries
                    .sortedByDescending { it.value }
                    .map { it.key }
                    .filter { it in unassigned }
                    .take(2)
            unassigned.removeAll(friends.toSet())
            val cluster = listOf(seed) + friends

            val pool =
                cluster
                    .flatMap { profile.artistSongs[it].orEmpty() }
                    .distinct()
                    .sortedByDescending { profile.songScore[it] ?: 0.0 }
                    .mapNotNull { profile.songs[it] }
                    .filter(allowed)
                    .take(RecommendationConfig.DAILY_MIX_SIZE)

            val rng = Random(now.toLocalDate().toEpochDay() * 31 + number)
            val filler =
                if (pool.size < RecommendationConfig.DAILY_MIX_SIZE) {
                    relatedUnplayed(profile, pool.take(3).map { it.id }, allowed)
                        .shuffled(rng)
                        .take(RecommendationConfig.DAILY_MIX_SIZE - pool.size)
                } else {
                    emptyList()
                }

            val songs = (pool + filler).distinctBy { it.id }
            if (songs.size < RecommendationConfig.MIN_MIX_SIZE) continue

            mixes +=
                RecommendationMix(
                    id = "daily_mix_$number",
                    kind = MixKind.DAILY_MIX,
                    title = "Daily Mix $number",
                    subtitle = artistLine(profile, cluster),
                    // Same order all day (seeded), but fresh tomorrow.
                    songs = spaceArtists(songs.shuffled(rng)),
                )
            number++
        }
        return mixes
    }

    /** Songs you tend to play at this time of day. */
    private fun timeOfDay(
        profile: TasteProfile,
        now: LocalDateTime,
        allowed: (Song) -> Boolean,
    ): RecommendationMix? {
        val bucket = TimeBucket.of(now.hour)
        val songs =
            profile.bucketScore[bucket].orEmpty().entries
                .sortedByDescending { it.value }
                .mapNotNull { profile.songs[it.key] }
                .filter(allowed)
        val picked = diversify(songs, RecommendationConfig.SHELF_SIZE)
        if (picked.size < RecommendationConfig.MIN_MIX_SIZE) return null
        return RecommendationMix(
            id = "time_${bucket.name.lowercase()}",
            kind = MixKind.TIME_OF_DAY,
            title = bucket.mixTitle,
            subtitle = bucket.mixSubtitle,
            songs = spaceArtists(picked),
        )
    }

    /** Songs you played a lot, but not for a while. */
    private fun rediscover(
        profile: TasteProfile,
        now: LocalDateTime,
        allowed: (Song) -> Boolean,
    ): RecommendationMix? {
        val cutoff = now.minusDays(RecommendationConfig.REDISCOVER_AFTER_DAYS)
        val songs =
            rankedIds(profile)
                .filter { id ->
                    (profile.playCount[id] ?: 0) >= RecommendationConfig.MIN_PLAYS_FOR_REDISCOVER &&
                        profile.lastPlayed[id]?.isBefore(cutoff) == true
                }
                .mapNotNull { profile.songs[it] }
                .filter(allowed)
        val picked = diversify(songs, RecommendationConfig.SHELF_SIZE)
        if (picked.size < RecommendationConfig.MIN_MIX_SIZE) return null
        return RecommendationMix(
            id = "rediscover",
            kind = MixKind.REDISCOVER,
            title = "Rediscover",
            subtitle = "Old favourites worth another listen",
            songs = spaceArtists(picked),
        )
    }

    /** Related songs to your favourites that you have never played. */
    private fun discover(
        profile: TasteProfile,
        random: Random,
        allowed: (Song) -> Boolean,
    ): RecommendationMix? {
        val songs =
            relatedUnplayed(profile, rankedIds(profile).take(8), allowed)
                .shuffled(random)
                .take(RecommendationConfig.SHELF_SIZE)
        if (songs.size < RecommendationConfig.MIN_MIX_SIZE) return null
        return RecommendationMix(
            id = "discover",
            kind = MixKind.DISCOVER,
            title = "Discover",
            subtitle = "New to you, close to your taste",
            songs = spaceArtists(songs),
        )
    }

    // ---------------------------------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------------------------------

    private fun relatedUnplayed(
        profile: TasteProfile,
        seedIds: List<String>,
        allowed: (Song) -> Boolean,
    ): List<Song> =
        seedIds
            .flatMap { runCatching { database.relatedSongs(it) }.getOrDefault(emptyList()) }
            .filter { it.id !in profile.playedIds && allowed(it) }
            .distinctBy { it.id }

    private fun topArtists(
        profile: TasteProfile,
        count: Int,
    ): List<String> = profile.artistScore.entries.sortedByDescending { it.value }.take(count).map { it.key }

    private fun artistLine(
        profile: TasteProfile,
        artistIds: List<String>,
    ): String {
        val names = artistIds.mapNotNull { profile.artistNames[it] }.take(3)
        return if (names.isEmpty()) "Based on your listening" else names.joinToString(", ")
    }

    /** Keeps ranking order but caps how many songs a single artist can contribute. */
    private fun diversify(
        ranked: List<Song>,
        limit: Int,
    ): List<Song> {
        val perArtist = HashMap<String?, Int>()
        val out = ArrayList<Song>()
        for (song in ranked) {
            if (out.size >= limit) break
            val artist = song.primaryArtistId()
            val used = perArtist[artist] ?: 0
            if (artist != null && used >= RecommendationConfig.MAX_PER_ARTIST) continue
            perArtist[artist] = used + 1
            out += song
        }
        return out
    }

    companion object {
        /** Spreads artists out so the same one never plays twice in a row (when avoidable). */
        fun spaceArtists(songs: List<Song>): List<Song> {
            val remaining = songs.toMutableList()
            val out = ArrayList<Song>(songs.size)
            var lastArtist: String? = null
            while (remaining.isNotEmpty()) {
                val index = remaining.indexOfFirst { it.primaryArtistId() != lastArtist }.let { if (it < 0) 0 else it }
                val next = remaining.removeAt(index)
                out += next
                lastArtist = next.primaryArtistId()
            }
            return out
        }

        /**
         * Smart shuffle: weighted random order (higher-scored songs tend to come earlier),
         * then artist spacing. [scores] maps song id → affinity; unknown songs get a neutral weight.
         */
        fun smartShuffle(
            songs: List<Song>,
            scores: Map<String, Double> = emptyMap(),
            random: Random = Random.Default,
        ): List<Song> {
            val keyed =
                songs.map { song ->
                    val weight = 0.5 + (scores[song.id] ?: 0.0).coerceAtLeast(0.0)
                    // Efraimidis–Spirakis weighted shuffle key.
                    val key = random.nextDouble().coerceAtLeast(1e-9).pow(1.0 / weight)
                    song to key
                }
            return spaceArtists(keyed.sortedByDescending { it.second }.map { it.first })
        }

        private fun Song.primaryArtistId(): String? = artists.firstOrNull()?.id
    }
}

/** Everything the engine learned about the listener. Immutable snapshot used while building mixes. */
internal class TasteProfile(
    val songs: Map<String, Song>,
    val songScore: Map<String, Double>,
    val playCount: Map<String, Int>,
    val lastPlayed: Map<String, LocalDateTime>,
    val playedIds: Set<String>,
    val artistScore: Map<String, Double>,
    val artistNames: Map<String, String>,
    val artistSongs: Map<String, List<String>>,
    val coListen: Map<String, Map<String, Int>>,
    val bucketScore: Map<TimeBucket, Map<String, Double>>,
)
